create
    definer = root@localhost procedure auto_insert1()
BEGIN
 declare i int default 1;
 while(i<3000000)do
 insert into s1 values(i,'duoduo','male',concat('duoduo',i,'@oldboy'));
 set i=i+1;
 end while;
END;

