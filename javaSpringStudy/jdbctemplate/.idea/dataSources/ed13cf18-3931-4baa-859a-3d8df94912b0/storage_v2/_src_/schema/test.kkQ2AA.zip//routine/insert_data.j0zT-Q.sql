create
    definer = root@localhost procedure insert_data()
BEGIN
DECLARE i INT DEFAULT 0;
WHILE(i<=10000) DO
BEGIN
SELECT i;
SET i=i+1;
INSERT INTO dept(deptName,salary,createDate,remark) VALUES(i,20000,NOW(),'test');
END ;
END WHILE;
    END;

